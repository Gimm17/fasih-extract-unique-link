'use strict';
importScripts('core.js', 'storage.js');
let queue = Promise.resolve();
function isFasih(sender) {
  try { return sender.id === chrome.runtime.id && Boolean(sender.tab) && Boolean(Fasih.context(sender.url)); }
  catch { return false; }
}
async function handle(msg, sender) {
  const ownPage = sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL('export.html'));
  if (!isFasih(sender) && !ownPage) throw new Error('Pesan tidak berasal dari halaman FASIH/ekspor ekstensi.');
  if (msg.type === 'LATEST') return FasihStore.latest(Fasih.context(sender.url).scope);
  if (msg.type === 'READ') {
    const job = await FasihStore.getJob(msg.id);
    if (!ownPage && job?.context.scope !== Fasih.context(sender.url).scope) throw new Error('Hasil berada pada survei lain.');
    return { job, rows: await FasihStore.getRows(msg.id), owned: job?.owner === sender.tab?.id };
  }
  if (ownPage) throw new Error('Halaman ekspor hanya dapat membaca hasil.');
  const ctx = Fasih.context(sender.url);
  if (msg.type === 'CREATE') {
    const priorId = await FasihStore.latest(ctx.scope);
    const prior = priorId && await FasihStore.getJob(priorId);
    if (prior?.status === 'RUNNING') throw new Error('Proses sebelumnya masih berjalan. Jeda/hentikan dahulu.');
    const startUrl = new URL(sender.url); startUrl.searchParams.set('perPage', '100');
    const job = { id: crypto.randomUUID(), context: Fasih.context(startUrl.href), options: msg.options,
      status: 'RUNNING', phase: 'INVENTORY', owner: sender.tab.id, createdAt: new Date().toISOString(),
      pages: {}, visitPages: [], processPages: [], attempted: [], notice: '', navigating: null };
    return FasihStore.create(job);
  }
  if (msg.type === 'EXPORT') {
    await chrome.tabs.create({ url: chrome.runtime.getURL('export.html') + '?job=' + encodeURIComponent(msg.id) });
    return true;
  }
  const job = await FasihStore.getJob(msg.id);
  if (!job || job.context.scope !== ctx.scope) throw new Error('Proses tidak cocok dengan survei aktif.');
  if (msg.type === 'CLAIM') {
    if (job.owner !== sender.tab.id) {
      let tab;
      try { tab = await chrome.tabs.get(job.owner); } catch { /* Previous tab is closed. */ }
      let sameScope=false;
      try {sameScope=Boolean(tab && Fasih.context(tab.url).scope===ctx.scope);}catch{/* Old tab id may have been reused by Chrome. */}
      if (sameScope && job.status === 'RUNNING') throw new Error('Proses dimiliki tab FASIH lain yang masih berjalan.');
      if (sameScope) throw new Error('Tutup tab pemilik proses sebelumnya dahulu agar dua tab tidak memproses data yang sama.');
    }
    return FasihStore.patchJob(job.id, { owner: sender.tab.id, status: 'RUNNING', navigating: null, notice: '' });
  }
  if (job.owner !== sender.tab.id) throw new Error('Hanya tab pemilik yang dapat mengubah progres.');
  if (msg.type === 'PATCH') return FasihStore.patchJob(job.id, msg.patch);
  if (msg.type === 'ROWS' || msg.type === 'CHECKPOINT') {
    if (!Array.isArray(msg.rows) || msg.rows.some(r => !r.key || Fasih.key(r.fields?.['Kode Identitas']) !== r.key)) {
      throw new Error('Identitas penyimpanan tidak valid.');
    }
    return msg.type === 'CHECKPOINT' ? FasihStore.checkpoint(job.id,msg.patch,msg.rows) : FasihStore.putRows(job.id, msg.rows);
  }
  throw new Error('Perintah tidak dikenal.');
}
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg || typeof msg.type !== 'string') return false;
  queue = queue.catch(() => {}).then(() => handle(msg, sender));
  queue.then(value => respond({ ok: true, value }), error => respond({ ok: false, error: error.message }));
  return true;
});
chrome.action.onClicked.addListener(async tab => {
  if (!tab.id) return;
  try { await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_PANEL' }); }
  catch { await chrome.tabs.create({ url: chrome.runtime.getURL('help.html') }); }
});
