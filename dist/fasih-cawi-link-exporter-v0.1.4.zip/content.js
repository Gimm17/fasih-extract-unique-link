(function () {
  'use strict';
  if(globalThis.__fasihBotPanel) return;
  const F=globalThis.Fasih;
  try { F.context(location.href); } catch { return; }
  globalThis.__fasihBotPanel=true;
  const host=document.createElement('div'); host.id='fasih-cawi-bot';
  host.style.cssText='position:fixed;right:16px;top:126px;z-index:2147483646;font:14px system-ui;color:#183042;pointer-events:auto;';
  const shadow=host.attachShadow({mode:'closed'});
  shadow.innerHTML=`<style>
    *{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;border:1px solid #cbd5e1;border-radius:7px;padding:9px;background:white;color:#183042}button:disabled{opacity:.45;cursor:default}.primary{background:#ee7918;border-color:#ee7918;color:white;font-weight:650}.panel{width:360px;max-height:calc(100vh - 150px);overflow:auto;background:#fff;border:1px solid #ccd7e0;border-radius:12px;box-shadow:0 8px 35px #16314630}.head{padding:14px 16px;display:flex;justify-content:space-between;align-items:center;background:#fff3e8;border-bottom:1px solid #e2e8f0}.head strong{font-size:16px}.body{padding:16px;display:grid;gap:12px}label{display:grid;gap:5px;font-size:12px;font-weight:650}input,select{padding:8px;border:1px solid #ccd7e0;border-radius:6px;width:100%;background:white;color:#183042}.row{display:grid;grid-template-columns:1fr 1fr;gap:8px}.muted{font-size:12px;line-height:1.5;color:#526b7c}.notice{font-size:12px;line-height:1.5;white-space:pre-wrap;word-break:break-word;border:1px solid #e2e8f0;background:#f7fafc;padding:10px;border-radius:7px}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}.stat{padding:8px;background:#f1f6fa;border-radius:6px;font-size:11px}.stat b{display:block;font-size:19px;color:#244a64}.hidden{display:none}.mini{box-shadow:0 4px 15px #16314620;background:#fff3e8}.meter{height:6px;background:#edf2f6;border-radius:6px;overflow:hidden}.meter div{height:100%;background:#ee7918;width:0}a{color:#244a64}
    .working{width:280px}.working .body{padding:10px;gap:8px}.working .body>*{display:none}.working .body>#state,.working .body>#notice{display:block}.working .body>#controls,.working .body>.stats{display:grid}.working .head{padding:10px}.working .head strong{font-size:13px}
  </style><button class="mini hidden" id="mini">FASIH Link · v0.1.4 · LINK</button><section class="panel" id="panel">
    <div class="head"><strong>FASIH · v0.1.4 · LINK</strong><button id="hide" aria-label="Sembunyikan panel">−</button></div>
    <div class="body"><div class="muted">LIST · ekstrak unique link · hanya OPEN dan CAWI<br>Kolom opsional yang tidak tampil boleh kosong.</div>
    <label>Wilayah<select id="region"><option value="Palu">Kota Palu</option><option value="Sulteng">Seluruh Sulawesi Tengah</option></select></label>
    <div class="row"><label>Awalan kode wilayah<input id="prefix" value="7271" inputmode="numeric" maxlength="16"></label><label>Domain link survei<input id="linkHost" value="esurvey.bps.go.id"></label></div>
    <div class="muted">Terapkan filter wilayah di FASIH. Awalan kode memeriksa bahwa setiap baris masih berada dalam cakupan.</div>
    <div class="row"><button id="diagnose">Cek data halaman</button><button id="pilot" class="primary">Pilot 5 data</button></div>
    <button id="all" class="primary">Mulai seluruh data pada filter</button>
    <div class="stats"><div class="stat">Inventaris<b id="total">0</b></div><div class="stat">Selesai<b id="done">0</b></div><div class="stat">Gagal<b id="error">0</b></div></div>
    <div class="meter"><div id="bar"></div></div><div class="muted" id="state">Belum ada proses.</div>
    <div class="row" id="controls"><button id="pause">Jeda</button><button id="resume">Lanjutkan</button><button id="stop">Hentikan</button><button id="retry">Coba ulang gagal</button></div>
    <button id="export">Ekspor Excel / backup</button><div class="notice" id="notice">Mulai dengan Cek data halaman. Pilot mengambil link maksimal 5 assignment OPEN yang sudah CAWI pada halaman pertama.</div>
    <div class="muted">Biarkan tab ini aktif saat berjalan. Progres disimpan lokal pada ekstensi. Setelah reload yang tidak direncanakan, tekan Lanjutkan.</div>
    </div></section>`;
  document.documentElement.appendChild(host);
  const $=id=>shadow.getElementById(id);
  const send=async message=> {
    const response=await chrome.runtime.sendMessage(message);
    if(!response?.ok) throw new Error(response?.error||'Koneksi penyimpanan ekstensi terputus.');
    return response.value;
  };
  const adapter=new F.Adapter();
  let loaded=null, busy=false, activity='';
  function show(value) { $('notice').textContent=value; }
  adapter.onActivity=value=>{activity=value;if(value)show(value);};
  function update({job,counts}) {
    loaded={job,rows:[...runner.records?.values()||[]],owned:true};
    for(const name of ['total','done','error']) $(name).textContent=counts[name].toLocaleString('id');
    $('bar').style.width=(job.phase==='INVENTORY'?counts.total?25:0:counts.total?100*(counts.done+counts.skipped)/counts.total:0)+'%';
    $('state').textContent=`${F.phaseLabel(job.phase)} · ${F.statusLabel(job.status)} · ${counts.skipped} dilewati · ${counts.pending} tertunda`;
    const working=job.status==='RUNNING'&&job.phase==='PROCESS';
    $('panel').classList.toggle('working',working);
    host.style.right=working?'auto':'16px';host.style.left=working?'16px':'auto';host.style.top=working?'16px':'126px';
    const lastFailure=job.lastFailure||loaded.rows.filter(r=>r.result==='ERROR').at(-1)?.error;
    if(job.notice) show(job.notice+(lastFailure&&!job.notice.includes(lastFailure)?'\nKegagalan terakhir: '+lastFailure:''));
    else show(activity||(job.phase==='INVENTORY'?`Mengambil kartu list. Halaman ${F.context(location.href).page}.`:`Mengambil unique link halaman ${F.context(location.href).page}.`));
    const active=runner.running||busy;
    for(const id of ['pilot','all','resume','retry','region','prefix','linkHost','diagnose']) $(id).disabled=active;
    $('export').disabled=!job;
  }
  const runner=new F.Runner(adapter,send,update);
  function options(pilot) {
    const prefix=$('prefix').value.trim(), linkHost=$('linkHost').value.trim().toLowerCase();
    if(!/^\d{2,16}$/.test(prefix)) throw new Error('Isi awalan kode wilayah, minimal 2 digit.');
    if(!/^[a-z0-9.-]+\.bps\.go\.id$/.test(linkHost)) throw new Error('Domain link harus merupakan subdomain bps.go.id.');
    return {region:$('region').value==='Palu'?'Kota Palu':'Sulawesi Tengah',prefix,linkHost,pilot,limit:pilot?5:0};
  }
  function restoreOptions(job) {
    $('region').value=job.options.region==='Kota Palu'?'Palu':'Sulteng';
    $('prefix').value=job.options.prefix; $('linkHost').value=job.options.linkHost;
  }
  async function readLatest() {
    const id=await send({type:'LATEST'});
    if(!id) return null;
    return send({type:'READ',id});
  }
  async function launch(pilot) {
    if(runner.running) return;
    const opts=options(pilot);
    // A launch from table routes to list before reading or processing assignments.
    if(F.context(location.href).view==='list') {
      await adapter.ready(opts.prefix);
      if(adapter.dialogs().length) throw new Error('Tutup popup FASIH dahulu.');
    }
    const job=await send({type:'CREATE',options:opts});
    await runner.start(job);
  }
  async function resume(retry=false) {
    const data=await readLatest();
    if(!data) throw new Error('Belum ada progres tersimpan.');
    restoreOptions(data.job);
    const job=await send({type:'CLAIM',id:data.job.id});
    await runner.resume(job,data.rows,retry);
  }
  function run(action) { return async()=> {
    if(busy) return; busy=true;
    try { await action(); } catch(e) { show(e.message); }
    finally { busy=false; if(loaded) update({job:loaded.job,counts:F.totals(loaded.rows)}); }
  }; }
  $('region').onchange=()=>{$('prefix').value=$('region').value==='Palu'?'7271':'72';};
  $('diagnose').onclick=run(async()=> {
    const result=adapter.diagnose(options(true).prefix);
    show(`Tampilan: ${result.view}\nKartu terbaca: ${result.rows}\nOPEN: ${result.open}\nOPEN dan CAWI: ${result.cawiOpen}\nStatus sumber: ${Object.entries(result.statuses).map(([s,n])=>s+': '+n).join(', ')}\nKolom: ${result.columns.length}\nNext dikenali: ${result.next?'ya':'tidak'}\n${result.ready?'Kartu list siap diproses. Popup akan diuji pada pilot.':result.issue}\nKolom opsional tidak tampil: ${result.missing.join(', ')||'tidak ada'}. Boleh kosong.`);
  });
  $('pilot').onclick=run(()=>launch(true)); $('all').onclick=run(()=>launch(false));
  async function control(stop) {
    if(runner.running) {runner.pause(stop);show(stop?'Hentikan diminta. Hasil yang tersimpan tetap tersedia.':'Jeda diminta. Menunggu tindakan aktif selesai/diverifikasi.');return;}
    if(!loaded?.job)return;
    try {const job=await send({type:'PATCH',id:loaded.job.id,patch:{status:stop?'STOPPED':'PAUSED',navigating:null}});update({job,counts:F.totals(loaded.rows)});}catch(e){show(e.message);}
  }
  $('pause').onclick=()=>control(false);
  $('stop').onclick=()=>control(true);
  $('resume').onclick=run(()=>resume(false)); $('retry').onclick=run(()=>resume(true));
  $('export').onclick=async()=>{try {const data=await readLatest();if(!data)throw new Error('Belum ada hasil.');await send({type:'EXPORT',id:data.job.id});}catch(e){show(e.message);}};
  function toggle() { $('panel').classList.toggle('hidden'); $('mini').classList.toggle('hidden'); }
  $('hide').onclick=toggle; $('mini').onclick=toggle;
  chrome.runtime.onMessage.addListener(msg=>{if(msg.type==='TOGGLE_PANEL')toggle();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&runner.running){runner.pause();show('Tab tidak aktif. Proses akan dijeda setelah tindakan aktif selesai.');}});
  (async()=> {
    try {
      const data=await readLatest(); if(!data) return;
      loaded=data; restoreOptions(data.job);
      runner.job=data.job; runner.records=new Map(data.rows.map(r=>[r.key,r]));
      update({job:data.job,counts:F.totals(data.rows)});
      const nav=data.job.navigating;
      if(data.owned && data.job.status==='RUNNING' && nav?.url===location.href && Date.now()-nav.at<120000) {
        await runner.start(data.job,data.rows);
      } else if(data.owned && data.job.status==='RUNNING') {
        const job=await send({type:'PATCH',id:data.job.id,patch:{status:'PAUSED',navigating:null,notice:'Halaman dimuat ulang. Aktifkan tab dan tekan Lanjutkan untuk memeriksa hasil aktual.'}});
        update({job,counts:F.totals(data.rows)});
      }
    } catch(e) { show(e.message); }
  })();
})();
